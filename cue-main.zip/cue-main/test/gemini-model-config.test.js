const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const path = require('node:path');

const { CURRENT_GEMINI_DEFAULT } = require('../src/llm');

// Google retired gemini-2.0-flash on 2026-03-03 (deprecated Feb 2026); every
// request against it 404s with a generic "exception parsing response" body —
// this is the root cause behind the cluster of "Error: got status: 404"
// bug reports. Before the fix, four different files each hardcoded their own
// Gemini model id (two still pointing at the dead one), so this scans every
// source file that talks to the Gemini API and fails if a known-retired id
// or a hardcoded id that has drifted from the shared default sneaks back in.
const DEAD_MODEL_IDS = ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.5-flash-lite', 'gemini-2.0-flash', 'gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-1.0-pro'];

const FILES_THAT_CALL_GEMINI = [
  'src/llm.js',
  'src/store.js',
  'src/stt.js',
  'src/stt-streaming.js'
];

test('CURRENT_GEMINI_DEFAULT is not a known-retired Gemini model id', () => {
  assert.ok(!DEAD_MODEL_IDS.includes(CURRENT_GEMINI_DEFAULT), `${CURRENT_GEMINI_DEFAULT} is on the known-dead list`);
});

for (const relPath of FILES_THAT_CALL_GEMINI) {
  test(`${relPath} does not hardcode a retired Gemini model id`, () => {
    const source = fs.readFileSync(path.join(__dirname, '..', relPath), 'utf8');
    for (const deadId of DEAD_MODEL_IDS) {
      assert.ok(!source.includes(`'${deadId}'`) && !source.includes(`"${deadId}"`),
        `${relPath} still references retired model ${deadId}`);
    }
  });
}

test('store.js default Gemini fast model matches the shared current default', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'src/store.js'), 'utf8');
  const match = /gemini:\s*\{\s*fast:\s*'([^']+)',\s*smart:\s*'([^']+)'/.exec(source);
  assert.ok(match, 'could not find the gemini default models block in store.js');
  assert.equal(match[1], CURRENT_GEMINI_DEFAULT);
  // smart may be a heavier model than the shared default, but never a dead one.
  assert.ok(match[2], 'store.js smart Gemini default is empty');
  assert.ok(!DEAD_MODEL_IDS.includes(match[2]), `${match[2]} is on the known-dead list`);
});
